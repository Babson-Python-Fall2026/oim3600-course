#Requires -Version 5.1
# =============================================================
#  OIM 3600  ·  Automated Environment Setup  ·  Fall 2026
# =============================================================
#
#  PHASE 1  --  Install software
#              Must run from Windows PowerShell 5 as Administrator
#
#              1. Press Start, type: Windows PowerShell
#              2. Right-click -> Run as Administrator
#              3. Run these three commands:
#                   cd C:\PythonClass
#                   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#                   .\setup50.ps1
#
#  PHASE 2  --  Configure environment
#              Must run from PowerShell 7 (normal user, no Admin)
#
#              1. Press Start, type: pwsh, press Enter
#              2. Run these two commands:
#                   cd C:\PythonClass
#                   .\setup50.ps1
#
#  NOTE: If you downloaded the setup files as a zip, unblock the zip
#        before extracting -- right-click the zip -> Properties ->
#        check Unblock -> OK -> then Extract All. All extracted files
#        will be unblocked automatically.
#
#  This script is safe to re-run at any time.
# =============================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -- display helpers -------------------------------------------
function Write-Banner {
    param($msg)
    $line = '-' * 60
    Write-Host "`n$line" -ForegroundColor White
    Write-Host "  $msg" -ForegroundColor White
    Write-Host "$line`n" -ForegroundColor White
}
function Write-Step { param($msg) Write-Host "  >> $msg" -ForegroundColor Cyan }
function Write-OK   { param($msg) Write-Host "  [OK] $msg" -ForegroundColor Green }
function Write-Warn { param($msg) Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-Fail { param($msg) Write-Host "  [FAIL] $msg" -ForegroundColor Red }

function Test-Cmd { param($name) return $null -ne (Get-Command $name -ErrorAction SilentlyContinue) }

# -- phase detection -------------------------------------------
$IsPS7   = $PSVersionTable.PSVersion.Major -ge 7
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$IsAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$MarkerFile = Join-Path $PSScriptRoot '.phase1-complete'

# =============================================================
#  PHASE 1 -- Install all required software
# =============================================================
function Invoke-Phase1 {

    Write-Banner 'PHASE 1 -- Software Installation'

    # -- unblock all scripts in C:\PythonClass -----------------
    # Files downloaded as a zip retain ZoneId=3 even after manual
    # unblock via Properties. Strip it now so all scripts run freely.
    # TIP: Unblocking the zip before extracting is the cleanest approach.
    Write-Step 'Unblocking course scripts...'
    Get-ChildItem -Path $PSScriptRoot -Filter '*.ps1' | Unblock-File
    Get-ChildItem -Path $PSScriptRoot -Filter '*.json' | Unblock-File
    Get-ChildItem -Path $PSScriptRoot -Filter '*.code-workspace' | Unblock-File
    Write-OK 'All course files unblocked'

    if (-not $IsAdmin) {
        Write-Fail 'Phase 1 must be run as Administrator.'
        Write-Host ''
        Write-Host '  How to fix:' -ForegroundColor Yellow
        Write-Host '  1. Close this window.' -ForegroundColor Yellow
        Write-Host '  2. Press Start -> type: Windows PowerShell' -ForegroundColor Yellow
        Write-Host '  3. Right-click -> Run as Administrator' -ForegroundColor Yellow
        Write-Host '  4. cd C:\PythonClass' -ForegroundColor Yellow
        Write-Host '  5. Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass' -ForegroundColor Yellow
        Write-Host '  6. .\setup50.ps1' -ForegroundColor Yellow
        exit 1
    }

    # -- winget check -----------------------------------------
    # WindowsApps may not be on PATH in PS5 -- add it explicitly
    $windowsAppsPath = "$env:LOCALAPPDATA\Microsoft\WindowsApps"
    if ($env:PATH -notmatch [regex]::Escape($windowsAppsPath)) {
        $env:PATH = "$windowsAppsPath;$env:PATH"
    }

    if (-not (Test-Cmd 'winget')) {
        Write-Fail 'winget not found. Update Windows App Installer from the Microsoft Store, then re-run.'
        exit 1
    }
    Write-OK "winget $(winget --version)"

    # -- remove conflicting Python installations ---------------
    Write-Step 'Checking for conflicting Python installations...'

    # Registry-based Python (python.org installer)
    $regRoots = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($root in $regRoots) {
        Get-ItemProperty $root -ErrorAction SilentlyContinue |
            Select-Object DisplayName, UninstallString, PSChildName |
            Where-Object {
                $_.DisplayName -and
                $_.DisplayName -match '^Python 3' -and
                $_.DisplayName -notmatch 'Anaconda|Miniconda'
            } |
            ForEach-Object {
                Write-Warn "Removing: $($_.DisplayName)"
                if ($_.UninstallString) {
                    Start-Process 'msiexec.exe' -ArgumentList "/X $($_.PSChildName) /quiet /norestart" -Wait -ErrorAction SilentlyContinue
                }
            }
    }

    # Microsoft Store Python
    Get-AppxPackage -Name 'PythonSoftwareFoundation*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            Write-Warn "Removing Microsoft Store Python: $($_.Name)"
            Remove-AppxPackage -Package $_.PackageFullName -ErrorAction SilentlyContinue
        }

    Write-OK 'Conflicting Python check complete'

    # -- install tools via winget ------------------------------
    # Go is required by the classroom50 gh extension (it compiles from source on install).
    # gh extension install foundation50/classroom50 will fail without Go on PATH.
    $tools = @(
        @{ Id = 'Microsoft.PowerShell';          Name = 'PowerShell 7'      },
        @{ Id = 'Microsoft.VisualStudioCode';    Name = 'Visual Studio Code' },
        @{ Id = 'Git.Git';                       Name = 'Git for Windows'   },
        @{ Id = 'GitHub.cli';                    Name = 'GitHub CLI'        },
        @{ Id = 'GoLang.Go';                     Name = 'Go'                }
    )

    foreach ($tool in $tools) {
        Write-Step "Installing $($tool.Name)..."
        $result = winget install `
            --id   $tool.Id `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements `
            --force 2>&1 | Out-String

        if ($LASTEXITCODE -eq 0 -or $result -match 'already installed|No applicable upgrade found') {
            Write-OK "$($tool.Name) ready"
        } else {
            Write-Warn "$($tool.Name) -- winget returned code $LASTEXITCODE (may still be OK, check below)"
        }
    }

    # -- Anaconda -----------------------------------------------------
    $anacondaPath      = "$env:USERPROFILE\anaconda3\python.exe"
    $anacondaConda     = "$env:USERPROFILE\anaconda3\Scripts\conda.exe"
    $minCondaMajor     = 23   # conda 23.x = mid-2023 minimum
    $anacondaInstalled = Test-Path $anacondaPath

    if ($anacondaInstalled) {
        $condaVerRaw = (& $anacondaConda --version 2>$null) -replace 'conda ', ''
        $condaMajor  = [int]($condaVerRaw -split '\.')[0]

        if ($condaMajor -ge $minCondaMajor) {
            Write-OK "Anaconda already installed and up to date (conda $condaVerRaw)"
        } else {
            Write-Warn "Anaconda too old (conda $condaVerRaw) -- minimum is $minCondaMajor.x -- reinstalling..."

            $uninstaller = "$env:USERPROFILE\anaconda3\Uninstall-Anaconda3.exe"
            if (Test-Path $uninstaller) {
                Write-Step 'Uninstalling old Anaconda...'
                Start-Process $uninstaller -ArgumentList '/S' -Wait
                Write-OK 'Old Anaconda uninstalled'
            } else {
                Write-Warn 'Uninstaller not found -- trying winget uninstall...'
                winget uninstall --id Anaconda.Anaconda3 --silent 2>&1 | Out-Null
            }

            foreach ($dir in @(
                "$env:USERPROFILE\anaconda3",
                "$env:USERPROFILE\AppData\Local\conda",
                "$env:USERPROFILE\.conda"
            )) {
                if (Test-Path $dir) {
                    Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
                    Write-OK "Removed leftover: $dir"
                }
            }
            $anacondaInstalled = $false
        }
    }

    if (-not $anacondaInstalled) {
        Write-Step 'Installing Anaconda (this takes several minutes -- please wait)...'

        $override = '/S /InstallationType=JustMe /RegisterPython=1 /AddToPath=0 /D={0}\anaconda3' -f $env:USERPROFILE

        $result = winget install `
            --id Anaconda.Anaconda3 `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements `
            --override $override 2>&1 | Out-String

        if (Test-Path $anacondaPath) {
            Write-OK 'Anaconda installed'
        } else {
            Write-Warn 'Anaconda winget install may have failed -- trying direct download fallback...'
            Install-AnacondaDirect
        }
    }

    # -- write phase-1 marker ----------------------------------
    Set-Content -Path $MarkerFile -Value (Get-Date).ToString('u') -Encoding UTF8

    Write-Banner 'PHASE 1 COMPLETE'
    Write-Host '  Next steps:' -ForegroundColor White
    Write-Host '  1. Close this Administrator window.' -ForegroundColor White
    Write-Host '  2. Press Start -> type: pwsh -> press Enter  (PowerShell 7)' -ForegroundColor White
    Write-Host '  3. cd C:\PythonClass' -ForegroundColor White
    Write-Host "  4. .\setup50.ps1`n" -ForegroundColor White
}

# -- Anaconda direct-download fallback -------------------------
# Fetches the latest installer version dynamically from the Anaconda
# archive index so this fallback does not go stale between semesters.
function Install-AnacondaDirect {
    Write-Step 'Fetching latest Anaconda installer URL...'

    $installerUrl = $null
    try {
        # The archive index lists all releases; grab the latest Windows x86_64 exe
        $archiveIndex = Invoke-WebRequest -Uri 'https://repo.anaconda.com/archive/' -UseBasicParsing
        $latestExe = ($archiveIndex.Links.href |
            Where-Object { $_ -match 'Anaconda3-\d{4}\.\d+-\d+-Windows-x86_64\.exe' } |
            Sort-Object -Descending |
            Select-Object -First 1)

        if ($latestExe) {
            $installerUrl = "https://repo.anaconda.com/archive/$latestExe"
            Write-OK "Latest Anaconda installer: $latestExe"
        }
    } catch {
        Write-Warn "Could not fetch archive index: $_"
    }

    # Hard-coded fallback in case the index fetch fails
    if (-not $installerUrl) {
        $installerUrl = 'https://repo.anaconda.com/archive/Anaconda3-2025.12-2-Windows-x86_64.exe'
        Write-Warn "Using pinned fallback installer URL: $installerUrl"
    }

    $dest = "$env:TEMP\Anaconda3-installer.exe"
    Write-Step "Downloading Anaconda to $dest ..."
    try {
        Invoke-WebRequest -Uri $installerUrl -OutFile $dest -UseBasicParsing
        Write-Step 'Running Anaconda installer silently...'
        $args = "/S /InstallationType=JustMe /RegisterPython=1 /AddToPath=0 /D=$env:USERPROFILE\anaconda3"
        Start-Process -FilePath $dest -ArgumentList $args -Wait
        if (Test-Path "$env:USERPROFILE\anaconda3\python.exe") {
            Write-OK 'Anaconda installed via direct download'
        } else {
            Write-Fail 'Anaconda installation failed. Please install manually from https://www.anaconda.com/download'
        }
    } catch {
        Write-Fail "Direct download failed: $_"
        Write-Host '  Please install Anaconda manually from https://www.anaconda.com/download' -ForegroundColor Yellow
        Write-Host '  Use these options: Just Me | No PATH | Register as default Python' -ForegroundColor Yellow
    }
}

# =============================================================
#  PHASE 2 -- Configure environment
# =============================================================
function Invoke-Phase2 {

    Write-Banner 'PHASE 2 -- Configuration'

    if (-not (Test-Path $MarkerFile)) {
        Write-Warn 'Phase 1 marker not found -- have you run Phase 1 as Administrator?'
        $continue = Read-Host '  Continue anyway? (y/n)'
        if ($continue -ne 'y') { exit 0 }
    }

    # -- verify tools are available ----------------------------
    Write-Step 'Verifying installed tools...'
    # Refresh PATH once so winget installs from Phase 1 (including Go) are visible
    $env:PATH = [System.Environment]::GetEnvironmentVariable('PATH', 'Machine') + ';' +
                [System.Environment]::GetEnvironmentVariable('PATH', 'User')

    $missing = @()
    foreach ($cmd in @('conda', 'code', 'git', 'gh', 'go')) {
        if (Test-Cmd $cmd) { Write-OK "$cmd found" }
        else               { Write-Warn "$cmd not found -- it may require opening a fresh window"; $missing += $cmd }
    }

    # -- clean up any old / duplicate profiles -----------------
    Write-Step 'Cleaning up old PowerShell profiles...'
    $oldProfiles = @(
        "$env:USERPROFILE\Documents\WindowsPowerShell\profile.ps1",
        "$env:USERPROFILE\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1",
        "$env:USERPROFILE\Documents\PowerShell\profile.ps1"
    )
    foreach ($p in $oldProfiles) {
        if (Test-Path $p) {
            Remove-Item $p -Force
            Write-Warn "Removed old profile: $p"
        }
    }
    Write-OK 'Profile cleanup done'

    # -- initialise conda for PowerShell 7 ---------------------
    Write-Step 'Initialising conda for PowerShell 7...'
    $condaBat = "$env:USERPROFILE\anaconda3\condabin\conda.bat"
    if (-not (Test-Path $condaBat)) {
        Write-Fail "Anaconda not found at $env:USERPROFILE\anaconda3 -- re-run Phase 1."
        exit 1
    }
    & $condaBat init powershell 2>&1 | Out-Null
    Write-OK 'Conda initialised for PowerShell'

    & $condaBat config --set auto_activate_base false 2>&1 | Out-Null
    Write-OK 'auto_activate_base = false  (conda only active inside VS Code)'

    # -- configure git identity --------------------------------
    Write-Step 'Configuring Git identity...'
    $gitName  = git config --global user.name  2>$null
    $gitEmail = git config --global user.email 2>$null

    if (-not $gitName -or -not $gitEmail) {
        Write-Host ''
        Write-Host '  Git needs your name and Babson email.' -ForegroundColor Yellow
        $inputName  = Read-Host '  Your full name (e.g., Alex Smith)'
        $inputEmail = Read-Host '  Your Babson email (e.g., asmith26@babson.edu)'
        git config --global user.name  $inputName
        git config --global user.email $inputEmail
        Write-OK "Git identity set: $inputName <$inputEmail>"
    } else {
        Write-OK "Git identity already set: $gitName <$gitEmail>"
    }

    # -- GitHub username helper --------------------------------
    Write-Banner 'GitHub Account Setup'
    Write-Host '  Your GitHub username MUST follow this exact format:' -ForegroundColor White
    Write-Host ''
    Write-Host '      firstname-fall2026' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '  Rules:' -ForegroundColor White
    Write-Host '    [OK] all lowercase letters' -ForegroundColor Green
    Write-Host '    [OK] first name only (no last name, no initials)' -ForegroundColor Green
    Write-Host '    [OK] single hyphen between name and semester' -ForegroundColor Green
    Write-Host '    [FAIL] no dots, underscores, or numbers in your name' -ForegroundColor Red
    Write-Host '    [FAIL] do not change the -fall2026 part' -ForegroundColor Red
    Write-Host ''

    do {
        $firstName = (Read-Host '  Enter your first name (letters only)').Trim().ToLower()
        if ($firstName -notmatch '^[a-z]+$') {
            Write-Warn '  Letters only -- no spaces, numbers, dots, or symbols. Try again.'
            $firstName = ''
        }
    } while (-not $firstName)

    # Instructor account exceptions -- these map to exact GitHub usernames
    # and do not get the -fall2026 suffix that students use.
    # $isInstructor controls auth path (gh teacher login) and skips signup browser.
    if ($firstName -eq 'rsail') {
        $githubUsername = 'rsail'
        $isInstructor   = $true
    } elseif ($firstName -eq 'rslotpole') {
        $githubUsername = 'rslotpole-babson'
        $isInstructor   = $true
    } else {
        $githubUsername = "$firstName-fall2026"
        $isInstructor   = $false
    }

    $usernameLen = $githubUsername.Length
    $pad         = ' ' * [Math]::Max(0, 37 - $usernameLen)

    Write-Host ''
    Write-Host '  +-----------------------------------------+' -ForegroundColor Green
    Write-Host '  │  Use this EXACT username on GitHub:     │' -ForegroundColor Green
    Write-Host "  │                                         │" -ForegroundColor Green
    Write-Host "  │    $githubUsername$pad│" -ForegroundColor Green
    Write-Host '  │                                         │' -ForegroundColor Green
    Write-Host '  │  Copy it now before clicking below.     │' -ForegroundColor Green
    Write-Host '  +-----------------------------------------+' -ForegroundColor Green
    Write-Host ''

    # Save username for sync50.ps1
    $configFile = Join-Path $PSScriptRoot '.student_config.txt'
    Set-Content -Path $configFile -Value $githubUsername -Encoding UTF8
    Write-OK "Username saved to .student_config.txt"

    # Students need to create a GitHub account; instructors already have one.
    if (-not $isInstructor) {
        Write-Host ''
        Write-Host '  Next: create your GitHub account at https://github.com/join' -ForegroundColor Yellow
        Write-Host '  Use your Babson email address and verify it before continuing.' -ForegroundColor Yellow
        Write-Host '  (Opening in your default browser...)' -ForegroundColor DarkGray
        Write-Host ''
        [System.Diagnostics.Process]::Start('cmd', '/c start https://github.com/join') | Out-Null
        Read-Host '  Press Enter once your GitHub account is created and email is verified'
    }

    # -- write $PROFILE ----------------------------------------
    # Written after $githubUsername is known so GH_CONFIG_DIR is correct.
    # GH_CONFIG_DIR isolates each user's gh credentials so that switching
    # between teacher and student accounts on the same machine during
    # testing does not clobber each other's auth state.
    Write-Step 'Writing PowerShell profile...'
    $profilePath = "$env:USERPROFILE\Documents\PowerShell\Microsoft.PowerShell_profile.ps1"
    $profileDir  = Split-Path $profilePath

    if (-not (Test-Path $profileDir)) {
        New-Item -ItemType Directory -Path $profileDir -Force | Out-Null
    }

    $profileContent = @"
# ------------------------------------
# Clean PowerShell Profile (NO FLASH)
# ------------------------------------
# Ensure winget-installed tools (gh, go, git, code) are always on PATH
`$env:PATH = [System.Environment]::GetEnvironmentVariable('PATH', 'Machine') + ';' +
             [System.Environment]::GetEnvironmentVariable('PATH', 'User')
Set-Alias notepad "C:\Windows\System32\notepad.exe"
`$env:GH_CONFIG_DIR = "`$env:USERPROFILE\.config\gh-$githubUsername"
# Load Conda hook + activate base ONLY in VS Code
if (`$env:TERM_PROGRAM -eq "vscode") {
    if (Test-Path "`$env:USERPROFILE\anaconda3\Scripts\conda.exe") {
        (& "`$env:USERPROFILE\anaconda3\Scripts\conda.exe" "shell.powershell" "hook") |
            Out-String | Invoke-Expression
        conda activate base *> `$null
    }
}
"@
    [System.IO.File]::WriteAllText($profilePath, $profileContent, [System.Text.Encoding]::UTF8)
    Write-OK "Profile written: $profilePath"

    # -- install VS Code extensions ----------------------------
    $extensions = @(
        @{ Id = 'ms-python.python';              Name = 'Python (Microsoft)'        },
        @{ Id = 'ms-toolsai.jupyter';            Name = 'Jupyter (Microsoft)'       },
        @{ Id = 'ms-vsliveshare.vsliveshare';    Name = 'Live Share (Microsoft)'    },
        @{ Id = 'ritwickdey.liveserver';         Name = 'Live Server (Ritwick Dey)' },
        @{ Id = 'eamodio.gitlens';               Name = 'GitLens (GitKraken)'       },
        @{ Id = 'michaelcurrin.auto-commit-msg'; Name = 'Auto Commit Message'       },
        @{ Id = 'tomoki1207.pdf';                Name = 'vscode-pdf'                }
    )

    # Refresh PATH again -- VS Code was installed in Phase 1 and its
    # PATH entry may not be in the current session.
    $env:PATH = [System.Environment]::GetEnvironmentVariable('PATH', 'Machine') + ';' +
                [System.Environment]::GetEnvironmentVariable('PATH', 'User')

    if (Test-Cmd 'code') {
        # Kill any running VS Code instances before installing extensions.
        # If VS Code is already open, 'code --install-extension' hands off to
        # the running instance and may not complete the install properly.
        $codeProcs = Get-Process -Name 'Code' -ErrorAction SilentlyContinue
        if ($codeProcs) {
            Write-Step 'Closing VS Code before extension install...'
            $codeProcs | Stop-Process -Force
            Start-Sleep -Seconds 3
            Write-OK 'VS Code closed'
        }

        Write-Step 'Installing VS Code extensions...'
        foreach ($ext in $extensions) {
            Write-Step "  $($ext.Name) ..."
            code --install-extension $ext.Id --force 2>&1 | Out-Null
            Write-OK "  $($ext.Name) installed"
        }
        Write-OK 'All extensions installed'
    } else {
        Write-Warn 'VS Code (code) not found on PATH -- extensions skipped. Open a fresh window and re-run.'
    }

    # -- write VS Code user settings ---------------------------
    Write-Step 'Writing VS Code user settings.json...'
    $vsCodeUserDir      = "$env:APPDATA\Code\User"
    $vsCodeUserSettings = "$vsCodeUserDir\settings.json"

    if (-not (Test-Path $vsCodeUserDir)) {
        New-Item -ItemType Directory -Path $vsCodeUserDir -Force | Out-Null
    }

    $userSettingsSrc = Join-Path $PSScriptRoot 'user-settings50.json'
    if (Test-Path $userSettingsSrc) {
        $settingsContent = Get-Content $userSettingsSrc -Raw
        $windowsUser     = $env:USERNAME
        $settingsContent = $settingsContent -replace 'WINDOWS-USER-NAME', $windowsUser
        [System.IO.File]::WriteAllText($vsCodeUserSettings, $settingsContent, [System.Text.Encoding]::UTF8)
        Write-OK "User settings.json written (interpreter path set for user: $windowsUser)"
    } else {
        Write-Warn "user-settings50.json not found in $PSScriptRoot -- skipping. Copy it to C:\PythonClass and re-run."
    }

    # -- generate .code-workspace file in student_repo ---------
    Write-Step 'Generating workspace file...'
    $workspaceDir = 'C:\PythonClass\student_repo'
    $workspaceDst = "$workspaceDir\oim3600.code-workspace"
    $windowsUser  = $env:USERNAME

    if (-not (Test-Path $workspaceDir)) {
        New-Item -ItemType Directory -Path $workspaceDir -Force | Out-Null
        Write-OK 'student_repo folder created'
    }

    $workspaceContent = @"
{
    "folders": [{ "path": "." }],
    "settings": {
        "python.defaultInterpreterPath": "C:\\Users\\$windowsUser\\anaconda3\\python.exe",
        "python.terminal.activateEnvironment": true,
        "terminal.integrated.defaultProfile.windows": "PowerShell",
        "terminal.integrated.profiles.windows": {
            "PowerShell": {
                "path": "C:\\Program Files\\PowerShell\\7\\pwsh.exe",
                "args": []
            }
        },
        "editor.formatOnSave": true,
        "editor.defaultFormatter": "ms-python.black-formatter",
        "[python]": { "editor.defaultFormatter": "ms-python.black-formatter" },
        "files.autoSave": "afterDelay",
        "files.autoSaveDelay": 1000,
        "notebook.lineNumbers": "on",
        "notebook.output.scrolling": true,
        "git.autofetch": true,
        "git.confirmSync": false,
        "workbench.colorTheme": "Tomorrow Night Blue"
    },
    "extensions": {
        "recommendations": [
            "ms-python.python",
            "ms-toolsai.jupyter",
            "ms-vsliveshare.vsliveshare",
            "ritwickdey.liveserver",
            "eamodio.gitlens",
            "michaelcurrin.auto-commit-msg",
            "tomoki1207.pdf"
        ]
    }
}
"@
    [System.IO.File]::WriteAllText($workspaceDst, $workspaceContent, [System.Text.Encoding]::UTF8)
    Write-OK "Workspace file generated: $workspaceDst"

    # -- create desktop shortcut -------------------------------
    Write-Step 'Creating desktop shortcut...'
    $shortcutPath = "$env:USERPROFILE\Desktop\OIM3600.lnk"
    $codeExe      = 'C:\Program Files\Microsoft VS Code\Code.exe'

    if (-not (Test-Path $codeExe)) {
        $codeCmd = Get-Command code -ErrorAction SilentlyContinue
        if ($codeCmd) { $codeExe = $codeCmd.Source }
    }

    if (Test-Path $codeExe) {
        $shell                     = New-Object -ComObject WScript.Shell
        $shortcut                  = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath       = $codeExe
        $shortcut.Arguments        = "`"$workspaceDst`""
        $shortcut.WorkingDirectory = $workspaceDir
        $shortcut.Description      = 'OIM3600 - Open course workspace'
        $shortcut.IconLocation     = "$codeExe,0"
        $shortcut.Save()
        Write-OK 'Desktop shortcut created: OIM3600.lnk'
        Write-Host '    -> Double-click OIM3600 on the desktop to open VS Code for class' -ForegroundColor DarkGray
    } else {
        Write-Warn 'Could not locate VS Code executable -- shortcut not created'
        Write-Warn "Create it manually: target = code.exe, argument = `"$workspaceDst`""
    }

    # -- clone and build classroom50 gh extensions -------------
    # The gh-student and gh-teacher extensions are built from source.
    # git clone uses the public HTTPS URL -- no auth required.
    # gh extension install . (local path) does not require auth either.
    # Auth happens afterwards via gh student login / gh teacher login.
    Write-Step 'Setting up classroom50 CLI extensions...'
    $env:PATH = [System.Environment]::GetEnvironmentVariable('PATH', 'Machine') + ';' +
                [System.Environment]::GetEnvironmentVariable('PATH', 'User')

    $c50Dir = 'C:\PythonClass\classroom50'
    if (Test-Path $c50Dir) {
        Write-Step 'Updating classroom50 repo...'
        git -C $c50Dir pull 2>&1 | Out-Null
        Write-OK 'classroom50 repo updated'
    } else {
        Write-Step 'Cloning classroom50 repo...'
        git clone https://github.com/foundation50/classroom50 $c50Dir 2>&1 | Out-Null
        if (Test-Path $c50Dir) {
            Write-OK 'classroom50 repo cloned'
        } else {
            Write-Fail 'Failed to clone classroom50 repo. Check your internet connection and re-run.'
            exit 1
        }
    }

    # Build and install gh-student (all users)
    Write-Step 'Building gh-student extension...'
    Push-Location "$c50Dir\cli\gh-student"
    try {
        go build . 2>&1 | Out-Null
        gh extension install . --force 2>&1 | Out-Null
        Write-OK 'gh-student extension installed'
    } catch {
        Write-Warn "gh-student build failed: $_"
    } finally {
        Pop-Location
    }

    # Build and install gh-teacher (instructor only)
    if ($isInstructor) {
        Write-Step 'Building gh-teacher extension...'
        Push-Location "$c50Dir\cli\gh-teacher"
        try {
            go build . 2>&1 | Out-Null
            gh extension install . --force 2>&1 | Out-Null
            Write-OK 'gh-teacher extension installed'
        } catch {
            Write-Warn "gh-teacher build failed: $_"
        } finally {
            Pop-Location
        }
    }

    # -- authenticate GitHub CLI -------------------------------
    # gh student login / gh teacher login handle auth with the correct
    # OAuth scopes (read:org + repo for students; admin:org for instructor).
    # They replace gh auth login and do not require a prior login.
    Write-Step 'Authenticating GitHub CLI...'
    Write-Host '  A browser window will open -- sign in with your GitHub account.' -ForegroundColor Yellow
    if ($isInstructor) {
        gh teacher login
    } else {
        gh student login
    }

    # -- summary -----------------------------------------------
    Write-Banner 'PHASE 2 COMPLETE'
    Write-Host '  Summary:' -ForegroundColor White
    Write-OK "PowerShell profile written (GH_CONFIG_DIR = gh-$githubUsername)"
    Write-OK "Conda configured (activates only inside VS Code)"
    Write-OK 'VS Code extensions installed'
    Write-OK "VS Code user settings.json written"
    Write-OK "Workspace file generated in student_repo"
    Write-OK "Desktop shortcut OIM3600 created"
    Write-OK "Git identity configured"
    Write-OK "GitHub username: $githubUsername"
    Write-OK "gh-student extension installed"
    if ($isInstructor) { Write-OK "gh-teacher extension installed" }
    Write-Host ''
    if ($isInstructor) {
        Write-Host '  Next: run gh teacher init to bootstrap your classroom.' -ForegroundColor White
    } else {
        Write-Host '  Next: go to the course page in Canvas and click' -ForegroundColor White
        Write-Host '  the classroom50 assignment link to accept' -ForegroundColor White
        Write-Host "  your repository.`n" -ForegroundColor White
        Write-Host '  Then run:  .\sync50.ps1' -ForegroundColor Cyan
    }
    Write-Host ''
}

# =============================================================
#  Entry point -- auto-detect phase
# =============================================================
Write-Host ''
Write-Host '  OIM 3600 -- Environment Setup' -ForegroundColor White
Write-Host '  Fall 2026' -ForegroundColor DarkGray
Write-Host ''

if ($IsPS7) {
    Write-Host '  Detected: PowerShell 7 -- running Phase 2' -ForegroundColor DarkGray
    Invoke-Phase2
} else {
    Write-Host '  Detected: Windows PowerShell 5 -- running Phase 1' -ForegroundColor DarkGray
    Invoke-Phase1
}
