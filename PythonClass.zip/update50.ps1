# ==========================================================
# sync50.ps1  (PUT THIS IN C:\PythonClass)
# ==========================================================
# One-command workflow:
#  - Ensure class_repo exists and is up to date
#  - Ensure student_repo exists (classroom50 repo)
#  - Safely sync class_repo -> student_repo using true-conflict rules
# ==========================================================

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

$startLocation = Get-Location

# ----------------------------------------------------------
# CONFIG
# ----------------------------------------------------------
$CLASS_ORG        = "Babson-Python-Fall2026"   # GitHub org (owned by rslotpole-babson)
$CLASS_REPO_NAME  = "Intro-to-Python"           # instructor template repo
$CLASSROOM_NAME   = "oim3600-fall2026"                   # classroom50 classroom name
$ASSIGNMENT_SLUG  = "intro-to-python"                    # classroom50 assignment slug

# classroom50 student repo naming convention:
#   <org>/<classroom>-<assignment>-<username>
# e.g.  Babson-Python-Fall2026/oim3600-fall2026-intro-to-python-alex-fall2026

$CLASS_REPO_SLUG = "$CLASS_ORG/$CLASS_REPO_NAME"

# ----------------------------------------------------------
# Root folder (script file location) -- works from anywhere
# ----------------------------------------------------------
$root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$classRepo   = Join-Path $root "class_repo"
$studentRepo = Join-Path $root "student_repo"
$configFile  = Join-Path $root ".student_config.txt"

Write-Host ""
Write-Host "=== Sync (Instructor -> Student) ===" -ForegroundColor Cyan
Write-Host "Root: $root" -ForegroundColor Cyan
Write-Host ""

# ----------------------------------------------------------
# Verify GitHub CLI
# ----------------------------------------------------------
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: GitHub CLI (gh) not found." -ForegroundColor Red
    Set-Location $startLocation
    exit 1
}

# ----------------------------------------------------------
# Git identity (safe defaults if missing)
# ----------------------------------------------------------
$gitUser  = git config --global user.name
$gitEmail = git config --global user.email
if (-not $gitUser -or -not $gitEmail) {
    git config --global user.name  "student"
    git config --global user.email "student@example.com"
}

# ----------------------------------------------------------
# Get GitHub username (cached)
# ----------------------------------------------------------
$username = ""
if (Test-Path $configFile) { $username = (Get-Content $configFile -Raw).Trim() }
if (-not $username) {
    $username = Read-Host "Enter your GitHub username (e.g., alex-fall2026)"
    if (-not $username) { Set-Location $startLocation; exit 1 }
    Set-Content -Path $configFile -Value $username -Encoding UTF8
}

# Build student repo slug using classroom50 naming convention
$studentRepoSlug = "$CLASS_ORG/$CLASSROOM_NAME-$ASSIGNMENT_SLUG-$username"
$upstreamUrl     = "https://github.com/$CLASS_REPO_SLUG.git"

Write-Host ""
Write-Host "Instructor repo: $CLASS_REPO_SLUG"    -ForegroundColor Green
Write-Host "Student repo:    $studentRepoSlug"     -ForegroundColor Green
Write-Host ""

# ----------------------------------------------------------
# Ensure class_repo exists + up to date
# ----------------------------------------------------------
if (-not (Test-Path $classRepo)) {
    Write-Host "Cloning instructor repo into class_repo..." -ForegroundColor Cyan
    gh repo clone $CLASS_REPO_SLUG $classRepo
}
Set-Location $classRepo
Write-Host "Updating class_repo (git pull)..." -ForegroundColor Cyan
git pull origin main | Out-Null

# ----------------------------------------------------------
# Ensure student_repo exists and is a git repo
# ----------------------------------------------------------
$studentGitDir = Join-Path $studentRepo ".git"
if (-not (Test-Path $studentRepo) -or -not (Test-Path $studentGitDir)) {
    Write-Host "Cloning student classroom50 repo into student_repo..." -ForegroundColor Cyan
    if (Test-Path $studentRepo) {
        # Folder exists but is not a git repo -- clone to temp then copy .git folder
        $tempRepo = "$studentRepo-temp"
        gh repo clone $studentRepoSlug $tempRepo
        Copy-Item -Path "$tempRepo\.git" -Destination $studentRepo -Recurse -Force
        Remove-Item $tempRepo -Recurse -Force
        Set-Location $studentRepo
        git checkout main 2>$null | Out-Null
    } else {
        gh repo clone $studentRepoSlug $studentRepo
    }
}

# ----------------------------------------------------------
# Verify student_repo origin belongs to org
# ----------------------------------------------------------
Set-Location $studentRepo
$originUrl = git remote get-url origin
if ($originUrl -notmatch [regex]::Escape($CLASS_ORG)) {
    Write-Host "ERROR: student_repo origin is not in expected org ($CLASS_ORG)." -ForegroundColor Red
    Write-Host "Origin: $originUrl"
    Set-Location $startLocation
    exit 1
}

# ----------------------------------------------------------
# Ensure upstream remote exists
# ----------------------------------------------------------
if (-not (git remote | Select-String "^upstream$")) {
    Write-Host "Adding upstream remote..." -ForegroundColor Cyan
    git remote add upstream $upstreamUrl
}

# ----------------------------------------------------------
# Save/push student work BEFORE applying updates
# ----------------------------------------------------------
$today = (Get-Date).ToString("yyyyMMdd")
Write-Host "Saving student work (commit/push if needed)..." -ForegroundColor Cyan
git add . | Out-Null
git commit -m "Local save before sync ($today)" 2>$null | Out-Null
git push origin main 2>$null | Out-Null

# ==========================================================
# SAFE FILE SYNC (hash + last-instructor state)
# ==========================================================

Write-Host ""
Write-Host "Applying instructor updates safely..." -ForegroundColor Cyan

$excludeNames = @(
    ".git", ".github", ".devcontainer", ".venv", "venv", "env", "__pycache__", ".DS_Store", "Thumbs.db"
)

function Is-Excluded([string]$relativePath) {
    foreach ($name in $excludeNames) {
        if ($relativePath -eq $name) { return $true }
        if ($relativePath -like "$name\*" -or $relativePath -like "*\$name\*") { return $true }
    }
    return $false
}

function Get-Hash([string]$path) {
    (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
}

# Store sync state outside the repo to avoid git conflicts
$stateDir = Join-Path $env:USERPROFILE ".pythonclass"
if (-not (Test-Path $stateDir)) { New-Item -ItemType Directory -Path $stateDir -Force | Out-Null }

$stateFileName = "sync_state.$CLASS_ORG.$CLASSROOM_NAME.$ASSIGNMENT_SLUG.$username.json"
$stateFile = Join-Path $stateDir $stateFileName

$state = @{}
if (Test-Path $stateFile) {
    try {
        $state = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json -AsHashtable
    } catch {
        Write-Host "WARNING: Could not read sync state; assuming first sync." -ForegroundColor Yellow
        $state = @{}
    }
}

$newFiles      = @()
$updatedFiles  = @()
$conflictFiles = @()
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

Get-ChildItem -LiteralPath $classRepo -Recurse -File | ForEach-Object {
    $src = $_.FullName
    $relative = $src.Substring($classRepo.Length + 1)

    if (Is-Excluded $relative) { return }

    $dest = Join-Path $studentRepo $relative
    $destDir = Split-Path $dest -Parent
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }

    $srcHash = Get-Hash $src

    if (-not (Test-Path $dest)) {
        Copy-Item -LiteralPath $src -Destination $dest -Force
        $state[$relative] = $srcHash
        $newFiles += $relative
        return
    }

    $destHash = Get-Hash $dest
    $lastInstructorHash = $null
    if ($state.ContainsKey($relative)) { $lastInstructorHash = $state[$relative] }

    if ($destHash -eq $srcHash) {
        $state[$relative] = $srcHash
        return
    }

    # student-only edit -> leave it
    if ($lastInstructorHash -and ($srcHash -eq $lastInstructorHash)) {
        return
    }

    # instructor-only update -> overwrite
    if ($lastInstructorHash -and ($destHash -eq $lastInstructorHash)) {
        Copy-Item -LiteralPath $src -Destination $dest -Force
        $state[$relative] = $srcHash
        $updatedFiles += $relative
        return
    }

    # true conflict -> timestamp student copy, install instructor version
    $backup = "$dest.student.$timestamp"
    Move-Item -LiteralPath $dest -Destination $backup -Force
    Copy-Item -LiteralPath $src -Destination $dest -Force
    $state[$relative] = $srcHash
    $conflictFiles += $relative
}

($state | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath $stateFile -Encoding UTF8

# Hide .vscode in Explorer
$vsCodePath = Join-Path $studentRepo ".vscode"
if (Test-Path $vsCodePath) { attrib +h $vsCodePath 2>$null | Out-Null }

Write-Host ""
Write-Host "=== Sync Summary ===" -ForegroundColor Cyan
if ($newFiles.Count)      { Write-Host "New:" -ForegroundColor Green;                       $newFiles      | ForEach-Object { Write-Host "  + $_" } }
if ($updatedFiles.Count)  { Write-Host "Updated:" -ForegroundColor Yellow;                  $updatedFiles  | ForEach-Object { Write-Host "  ~ $_" } }
if ($conflictFiles.Count) { Write-Host "Conflicts (student copy preserved):" -ForegroundColor Red; $conflictFiles | ForEach-Object { Write-Host "  ! $_" } }
if (-not $newFiles.Count -and -not $updatedFiles.Count -and -not $conflictFiles.Count) {
    Write-Host "No changes detected." -ForegroundColor Gray
}

# ----------------------------------------------------------
# Return to where user started
# ----------------------------------------------------------
Set-Location $startLocation
Write-Host ""
Write-Host "Sync complete." -ForegroundColor Green
Write-Host ""
