#Requires -Version 7.0
# =============================================================
#  OIM 3600  ·  Environment Validation Script  ·  Fall 2026
# =============================================================
#  Run from PowerShell 7 after setup50.ps1 Phase 2 completes:
#      cd C:\PythonClass
#      .\validate-env50.ps1
#
#  Reports PASS / WARN / FAIL for every requirement.
#  Makes NO changes to the system.
# =============================================================

$ErrorActionPreference = 'SilentlyContinue'

$passes = 0
$warns  = 0
$fails  = 0

function Write-Banner {
    param($msg)
    Write-Host "`n$('-' * 60)" -ForegroundColor DarkGray
    Write-Host "  $msg" -ForegroundColor White
    Write-Host "$('-' * 60)" -ForegroundColor DarkGray
}

function Pass {
    param($label, $detail = '')
    $script:passes++
    $suffix = if ($detail) { "  ($detail)" } else { '' }
    Write-Host "  [PASS]  $label$suffix" -ForegroundColor Green
}

function Warn {
    param($label, $detail = '')
    $script:warns++
    $suffix = if ($detail) { "  ($detail)" } else { '' }
    Write-Host "  [WARN]  $label$suffix" -ForegroundColor Yellow
}

function Fail {
    param($label, $detail = '')
    $script:fails++
    $suffix = if ($detail) { "  ($detail)" } else { '' }
    Write-Host "  [FAIL]  $label$suffix" -ForegroundColor Red
}

function Test-Cmd { param($name) return $null -ne (Get-Command $name -ErrorAction SilentlyContinue) }


function Test-ClassroomExtension {
    if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { return $false }

    # Test the command students actually use instead of parsing
    # the display format from `gh extension list`.
    & gh student --help *> $null
    return ($LASTEXITCODE -eq 0)
}

# =============================================================
#  1. POWERSHELL VERSIONS
# =============================================================
Write-Banner '1. PowerShell'

$ps7Ver = $PSVersionTable.PSVersion
if ($ps7Ver.Major -ge 7) {
    Pass 'PowerShell 7 is the current shell' "v$ps7Ver"
} else {
    Fail 'Not running in PowerShell 7' "current: v$ps7Ver -- open Start -> pwsh"
}

$ps5 = Get-Command powershell -ErrorAction SilentlyContinue
if ($ps5) {
    Pass 'Windows PowerShell 5 still present' $ps5.Source
} else {
    Warn 'Windows PowerShell 5 not found (unusual on Windows 11)'
}

# =============================================================
#  2. REQUIRED TOOLS
# =============================================================
Write-Banner '2. Required Tools'

$git = Get-Command git -ErrorAction SilentlyContinue
if ($git) {
    $gitVer = (git --version 2>$null) -replace 'git version ', ''
    Pass 'Git installed' $gitVer
} else {
    Fail 'Git not found'
}

$gh = Get-Command gh -ErrorAction SilentlyContinue
if ($gh) {
    $ghVer = (gh --version 2>$null | Select-Object -First 1) -replace 'gh version ', ''
    Pass 'GitHub CLI installed' $ghVer
} else {
    Fail 'GitHub CLI (gh) not found'
}

$code = Get-Command code -ErrorAction SilentlyContinue
if ($code) {
    $codeVer = (code --version 2>$null | Select-Object -First 1)
    Pass 'VS Code installed' $codeVer
} else {
    Fail 'VS Code (code) not found on PATH'
}

# Go -- required by gh extension install foundation50/classroom50
$goCmd = Get-Command go -ErrorAction SilentlyContinue
if ($goCmd) {
    $goVer = (go version 2>$null) -replace 'go version ', ''
    Pass 'Go installed' $goVer
} else {
    Fail 'Go not found -- required for classroom50 extension (install via winget: GoLang.Go)'
}

# Classroom gh extension
if (Get-Command gh -ErrorAction SilentlyContinue) {
    if (Test-ClassroomExtension) {
        Pass 'gh student extension installed and working'
    } else {
        Fail 'gh student extension is not working -- expected: gh student --help'
    }
} else {
    Warn 'Cannot check gh student extension -- gh not found'
}

# =============================================================
#  3. ANACONDA / PYTHON
# =============================================================
Write-Banner '3. Anaconda and Python'

$anacondaRoot   = "$env:USERPROFILE\anaconda3"
$anacondaPython = "$anacondaRoot\python.exe"
$anacondaConda  = "$anacondaRoot\Scripts\conda.exe"
$condaBat       = "$anacondaRoot\condabin\conda.bat"

if (Test-Path $anacondaPython) {
    $pyVer = (& $anacondaPython --version 2>$null) -replace 'Python ', ''
    Pass 'Anaconda installed at expected path' "Python $pyVer"
} else {
    Fail 'Anaconda not found' "expected: $anacondaRoot"
}

if (Test-Path $anacondaConda) {
    $condaVer = (& $anacondaConda --version 2>$null) -replace 'conda ', ''
    Pass 'conda.exe present' "v$condaVer"

    $minCondaMajor = 23
    $condaMajor    = [int]($condaVer -split '\.')[0]
    if ($condaMajor -ge $minCondaMajor) {
        Pass "Anaconda version meets minimum (conda $condaVer >= $minCondaMajor.x)"
    } else {
        Fail "Anaconda too old (conda $condaVer) -- minimum is $minCondaMajor.x -- re-run setup50.ps1 Phase 1"
    }
} else {
    Fail 'conda.exe not found' $anacondaConda
}

$pathEntries = $env:PATH -split ';'
$condaOnPath = $pathEntries | Where-Object {
    $_ -match 'anaconda3\\Scripts$' -or
    $_ -match 'anaconda3\\bin$'
}
if ($condaOnPath) {
    Fail 'Anaconda Scripts is on system PATH -- should NOT be' ($condaOnPath -join ', ')
} else {
    Pass 'Anaconda Scripts NOT on system PATH (correct)'
}

$condabinOnPath = $pathEntries | Where-Object { $_ -match 'anaconda3\\condabin' }
if ($condabinOnPath) {
    Warn 'condabin is on the global PATH -- not required by the VS Code-only conda design' ($condabinOnPath -join ', ')
} else {
    Pass 'condabin not on global PATH (correct -- conda is activated only inside VS Code)'
}

$pythonCmd = Get-Command python -ErrorAction SilentlyContinue
$insideVSCode = ($env:TERM_PROGRAM -eq 'vscode')

if ($insideVSCode) {
    if ($pythonCmd -and $pythonCmd.Source -match 'anaconda3') {
        Pass 'Inside VS Code, python resolves to Anaconda' $pythonCmd.Source
    } elseif ($pythonCmd) {
        Fail 'Inside VS Code, python does not resolve to Anaconda' $pythonCmd.Source
    } else {
        Fail 'Inside VS Code, python command not found -- conda activation/profile hook failed'
    }
} else {
    if (-not $pythonCmd) {
        Pass 'Outside VS Code, python is not on PATH (correct)'
    } elseif ($pythonCmd.Source -match 'anaconda3') {
        Warn 'Outside VS Code, python resolves to Anaconda (works, but global activation was not intended)' $pythonCmd.Source
    } elseif ($pythonCmd.Source -match '\\Microsoft\\WindowsApps\\python\.exe$') {
        Pass 'Outside VS Code, only the Windows app-execution alias resolves as python (harmless)'
    } else {
        Fail 'Outside VS Code, python resolves to an unexpected non-Anaconda install' $pythonCmd.Source
    }
}

$storePython = Get-AppxPackage -Name 'PythonSoftwareFoundation*' -ErrorAction SilentlyContinue
if ($storePython) {
    Fail 'Microsoft Store Python is installed -- conflicts with Anaconda' ($storePython.Name -join ', ')
} else {
    Pass 'No Microsoft Store Python installed'
}

$regRoots = @(
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
$conflictPython = foreach ($root in $regRoots) {
    Get-ItemProperty $root -ErrorAction SilentlyContinue |
        Select-Object DisplayName |
        Where-Object { $_.DisplayName -and $_.DisplayName -match '^Python 3' -and $_.DisplayName -notmatch 'Anaconda|Miniconda' }
}
if ($conflictPython) {
    Fail 'Conflicting Python installation found' ($conflictPython.DisplayName -join ', ')
} else {
    Pass 'No conflicting Python (python.org) installations'
}

$autoActivate = (& $anacondaConda config --get auto_activate_base 2>$null)
if ($autoActivate -match 'False|false') {
    Pass 'conda auto_activate_base = false'
} else {
    Warn 'conda auto_activate_base may not be false' "got: $autoActivate"
}

# =============================================================
#  4. POWERSHELL PROFILE
# =============================================================
Write-Banner '4. PowerShell Profile'

$expectedProfilePath = "$env:USERPROFILE\Documents\PowerShell\Microsoft.PowerShell_profile.ps1"

if (Test-Path $expectedProfilePath) {
    Pass 'Profile exists at correct path'
} else {
    Fail 'Profile not found' $expectedProfilePath
}

if (Test-Path $expectedProfilePath) {
    $profileContent = Get-Content $expectedProfilePath -Raw

    # Load the saved username so we can validate the GH_CONFIG_DIR pattern
    $configFile    = Join-Path $PSScriptRoot '.student_config.txt'
    $savedUsername = if (Test-Path $configFile) { (Get-Content $configFile -Raw).Trim() } else { '' }

    # Determine expected GH_CONFIG_DIR value
    # Instructor (rsail) has no semester suffix; students follow firstname-fall2026
    $expectedGhDir = if ($savedUsername) { "gh-$savedUsername" } else { 'gh-' }

    $checks = @(
        @{ Pattern = 'NO FLASH';              Label = 'Profile header present'          },
        @{ Pattern = 'Set-Alias notepad';     Label = 'notepad alias present'           },
        @{ Pattern = 'GH_CONFIG_DIR';         Label = 'GH_CONFIG_DIR set'              },
        @{ Pattern = [regex]::Escape($expectedGhDir);
                                              Label = "GH_CONFIG_DIR points to gh-$savedUsername" },
        @{ Pattern = 'TERM_PROGRAM.*vscode';  Label = 'conda hook gated on VS Code only' },
        @{ Pattern = 'conda activate base';   Label = 'conda activate base present'     }
    )

    foreach ($check in $checks) {
        if ($profileContent -match $check.Pattern) {
            Pass $check.Label
        } else {
            Fail $check.Label
        }
    }

    if ($profileContent -match '# >>> conda initialize >>>') {
        Fail 'Stray conda init block found in profile -- profile was not cleanly overwritten'
    } else {
        Pass 'No stray conda init block in profile'
    }
}

$interferingProfiles = @(
    "$env:USERPROFILE\Documents\PowerShell\profile.ps1",
    "$env:USERPROFILE\Documents\WindowsPowerShell\profile.ps1",
    "$env:USERPROFILE\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1"
)
foreach ($p in $interferingProfiles) {
    if (Test-Path $p) {
        Warn "Old/duplicate profile exists -- may interfere" $p
    }
}

# =============================================================
#  5. VS CODE SETTINGS
# =============================================================
Write-Banner '5a. VS Code User Settings'

$userSettingsPath = "$env:APPDATA\Code\User\settings.json"

if (Test-Path $userSettingsPath) {
    Pass 'User settings.json exists'
    try {
        $rawSettings = Get-Content $userSettingsPath -Raw
        $stripped    = $rawSettings -replace '(?m)^\s*//.*$', '' -replace ',\s*}', '}'
        $settings    = $stripped | ConvertFrom-Json

        $interpPath = $settings.'python.defaultInterpreterPath'
        if ($interpPath -match 'WINDOWS-USER-NAME') {
            Fail 'Interpreter path still contains WINDOWS-USER-NAME placeholder'
        } elseif ($interpPath -match [regex]::Escape($env:USERNAME)) {
            Pass 'Interpreter path contains real Windows username' $interpPath
        } else {
            Warn 'Interpreter path username does not match current user' $interpPath
        }

        $interpResolved = $interpPath -replace '/', '\'
        if (Test-Path $interpResolved) {
            Pass 'Interpreter path resolves to a real file'
        } else {
            Fail 'Interpreter path does not resolve to a file' $interpResolved
        }

        $userChecks = @(
            @{ Key = 'python.terminal.activateEnvironment';        Expected = $false;        Label = 'python.terminal.activateEnvironment = false' },
            @{ Key = 'python.createEnvironment.trigger';           Expected = 'off';         Label = 'createEnvironment.trigger = off'             },
            @{ Key = 'terminal.integrated.defaultProfile.windows'; Expected = 'PowerShell';  Label = 'default terminal = PowerShell (PS7)'         },
            @{ Key = 'chat.disableAIFeatures';                     Expected = $false;        Label = 'AI features enabled (disableAIFeatures=false)'},
            @{ Key = 'jupyter.jupyterServerType';                  Expected = 'local';       Label = 'Jupyter server = local'                      },
            @{ Key = 'workbench.colorTheme';                       Expected = 'Tomorrow Night Blue'; Label = 'Color theme set'                    }
        )

        foreach ($sc in $userChecks) {
            $val = $settings.($sc.Key)
            if ($null -eq $val) { Warn "$($sc.Label) -- key not found" }
            elseif ("$val" -eq "$($sc.Expected)") { Pass $sc.Label }
            else { Fail $sc.Label "got: $val" }
        }

    } catch {
        Warn 'Could not parse user settings.json' $_.Exception.Message
    }
} else {
    Fail 'User settings.json not found' $userSettingsPath
}

Write-Banner '5b. VS Code Workspace File'

# The workspace file lives in student_repo (generated by setup50.ps1)
$workspaceDst = 'C:\PythonClass\student_repo\oim3600.code-workspace'

if (Test-Path $workspaceDst) {
    Pass 'oim3600.code-workspace present in student_repo'
    try {
        $ws = Get-Content $workspaceDst -Raw | ConvertFrom-Json

        $wsChecks = @(
            @{ Key = 'editor.formatOnSave';       Expected = $true;        Label = 'formatOnSave = true'      },
            @{ Key = 'files.autoSave';            Expected = 'afterDelay'; Label = 'autoSave = afterDelay'    },
            @{ Key = 'files.autoSaveDelay';       Expected = 1000;         Label = 'autoSaveDelay = 1000ms'   },
            @{ Key = 'notebook.lineNumbers';       Expected = 'on';         Label = 'notebook.lineNumbers = on' },
            @{ Key = 'notebook.output.scrolling'; Expected = $true;        Label = 'notebook output scrolling' },
            @{ Key = 'git.autofetch';             Expected = $true;        Label = 'git.autofetch = true'     }
        )

        foreach ($sc in $wsChecks) {
            $val = $ws.settings.($sc.Key)
            if ($null -eq $val)                      { Warn "$($sc.Label) -- key not found in workspace file" }
            elseif ("$val" -eq "$($sc.Expected)")    { Pass $sc.Label }
            else                                     { Fail $sc.Label "got: $val" }
        }

    } catch {
        Warn 'Could not parse oim3600.code-workspace' $_.Exception.Message
    }
} else {
    Warn 'oim3600.code-workspace not found in student_repo -- run setup50.ps1 Phase 2 or update50.ps1'
}

# =============================================================
#  6. VS Code Extensions
# =============================================================
Write-Banner '6. VS Code Extensions'

$requiredExtensions = @(
    @{ Id = 'ms-python.python';              Name = 'Python (Microsoft)'        },
    @{ Id = 'ms-toolsai.jupyter';            Name = 'Jupyter (Microsoft)'       },
    @{ Id = 'ms-vsliveshare.vsliveshare';    Name = 'Live Share (Microsoft)'    },
    @{ Id = 'ritwickdey.liveserver';         Name = 'Live Server (Ritwick Dey)' },
    @{ Id = 'eamodio.gitlens';               Name = 'GitLens (GitKraken)'       },
    @{ Id = 'michaelcurrin.auto-commit-msg'; Name = 'Auto Commit Message'       },
    @{ Id = 'tomoki1207.pdf';                Name = 'vscode-pdf'                }
)

$dependencyExtensions = @(
    @{ Id = 'ms-python.vscode-pylance';             Name = 'Pylance'                    },
    @{ Id = 'ms-python.debugpy';                    Name = 'Python Debugger (debugpy)'  },
    @{ Id = 'ms-python.vscode-python-envs';         Name = 'Python Environments'        },
    @{ Id = 'ms-toolsai.jupyter-keymap';            Name = 'Jupyter Keymap'             },
    @{ Id = 'ms-toolsai.jupyter-renderers';         Name = 'Jupyter Notebook Renderers' },
    @{ Id = 'ms-toolsai.vscode-jupyter-cell-tags';  Name = 'Jupyter Cell Tags'          },
    @{ Id = 'ms-toolsai.vscode-jupyter-slideshow';  Name = 'Jupyter Slide Show'         }
)

# Extensions are installed into the default profile to avoid VS Code bug #251907
# (missing backslash in extensions path when using --profile on Windows)
if (Test-Cmd 'code') {
    $installedExts = (code --list-extensions 2>&1 | Out-String).Trim() -split "`n" |
                     ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ }

    Write-Host '  Checking explicitly installed extensions:' -ForegroundColor DarkGray
    foreach ($ext in $requiredExtensions) {
        if ($installedExts -contains $ext.Id.ToLower()) {
            Pass "$($ext.Name)" $ext.Id
        } else {
            Fail "$($ext.Name) NOT installed" $ext.Id
        }
    }

    Write-Host '  Checking auto-installed dependencies:' -ForegroundColor DarkGray
    foreach ($ext in $dependencyExtensions) {
        if ($installedExts -contains $ext.Id.ToLower()) {
            Pass "$($ext.Name)" $ext.Id
        } else {
            Warn "$($ext.Name) not found -- may not have installed yet" $ext.Id
        }
    }
} else {
    Warn 'Cannot check extensions -- VS Code (code) not on PATH'
}

# =============================================================
#  7. GIT IDENTITY
# =============================================================
Write-Banner '7. Git Identity'

$gitName  = git config --global user.name  2>$null
$gitEmail = git config --global user.email 2>$null

if ($gitName)  { Pass 'git user.name set'  $gitName  } else { Fail 'git user.name not set'  }
if ($gitEmail) {
    if ($gitEmail -match '@babson\.edu$') {
        Pass 'git user.email is a Babson address' $gitEmail
    } elseif ($gitEmail -eq 'pp353@mail.com') {
        Pass 'git user.email is approved test-account exception' $gitEmail
    } else {
        Warn 'git user.email is not a @babson.edu address' $gitEmail
    }
} else {
    Fail 'git user.email not set'
}

# =============================================================
#  8. GITHUB CLI, USERNAME, AND GH STUDENT
# =============================================================
Write-Banner '8. GitHub CLI, Username, and gh student'

$authOutput = gh auth status 2>&1 | Out-String
if ($authOutput -match 'Logged in') {
    Pass 'GitHub CLI authenticated'
} else {
    Fail 'GitHub CLI not authenticated -- run: gh auth login'
}

$configFile = Join-Path $PSScriptRoot '.student_config.txt'
if (Test-Path $configFile) {
    $savedUsername = (Get-Content $configFile -Raw).Trim()
    # Valid formats:
    #   normal student: firstname-fall2026
    #   instructor:     rsail
    #   test account:   pp353-fall2026
    if (
        $savedUsername -match '^[a-z]+-fall2026$' -or
        $savedUsername -eq 'rsail' -or
        $savedUsername -eq 'pp353-fall2026'
    ) {
        Pass 'Saved GitHub username format is correct' $savedUsername
    } else {
        Fail 'Saved GitHub username has wrong format' "got: $savedUsername -- expected firstname-fall2026 (or approved instructor/test account)"
    }
} else {
    Warn '.student_config.txt not found -- update50.ps1 will prompt for username'
}

# Classroom extension check (repeat here for summary visibility)
if (Get-Command gh -ErrorAction SilentlyContinue) {
    if (Test-ClassroomExtension) {
        Pass 'gh student extension installed and working'
    } else {
        Fail 'gh student extension is not working'
    }
}

# =============================================================
#  9. COURSE FOLDER AND DESKTOP SHORTCUT
# =============================================================
Write-Banner '9. Course Folder and Desktop Shortcut'

$expectedFiles = @(
    'setup50.ps1',
    'user-settings50.json',
    'update50.ps1',
    'validate-env50.ps1',
    'reset-env50.ps1'
)
foreach ($f in $expectedFiles) {
    $path = Join-Path $PSScriptRoot $f
    if (Test-Path $path) { Pass "$f present" }
    else                 { Warn  "$f not found in C:\PythonClass" }
}

$workspaceInRepo = 'C:\PythonClass\student_repo\oim3600.code-workspace'
if (Test-Path $workspaceInRepo) {
    Pass 'oim3600.code-workspace present in student_repo'
} else {
    Warn 'oim3600.code-workspace not in student_repo yet -- run setup50.ps1 Phase 2'
}

$shortcutPath = "$env:USERPROFILE\Desktop\OIM3600.lnk"
if (Test-Path $shortcutPath) {
    Pass 'Desktop shortcut OIM3600.lnk present'
} else {
    Warn 'Desktop shortcut not found -- re-run setup50.ps1 Phase 2'
}

# =============================================================
#  SUMMARY
# =============================================================
$total = $passes + $warns + $fails
Write-Host ''
Write-Host "$('=' * 60)" -ForegroundColor DarkGray
Write-Host '  VALIDATION SUMMARY' -ForegroundColor White
Write-Host "$('=' * 60)" -ForegroundColor DarkGray
Write-Host "  Total checks : $total" -ForegroundColor White
Write-Host "  Passed       : $passes" -ForegroundColor Green
if ($warns -gt 0) { Write-Host "  Warnings     : $warns" -ForegroundColor Yellow }
if ($fails -gt 0) { Write-Host "  Failed       : $fails" -ForegroundColor Red    }
Write-Host ''

if ($fails -eq 0 -and $warns -eq 0) {
    Write-Host '  Environment is fully configured. Ready for class.' -ForegroundColor Green
} elseif ($fails -eq 0) {
    Write-Host '  Environment looks good. Review warnings above.' -ForegroundColor Yellow
} else {
    Write-Host '  One or more checks failed. Fix items marked [FAIL] before class.' -ForegroundColor Red
}
Write-Host ''
